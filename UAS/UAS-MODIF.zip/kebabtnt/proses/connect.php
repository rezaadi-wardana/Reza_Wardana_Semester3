<?php
$conn = mysqli_connect("localhost","root","","db_kebabtnt");
if(!$conn){
    echo "gagal";
}
?>