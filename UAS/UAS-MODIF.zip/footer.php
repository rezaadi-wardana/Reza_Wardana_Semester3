<footer class="footer_section">
    <div class="container">
      <div class="row">
        <div class="col-md-4 footer-col">
          <div class="footer_contact">
            <h4>
              Hubungi Kami
            </h4>
            <div class="contact_link_box">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Lokasi
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Telp. +62 895-4035-94798
                </span>
              </a>
              <!-- <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  kebabtnt@gmail.com
                </span>
              </a> -->
            </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <div class="footer_detail">
            <a href="" class="footer-logo">
             Kebab & Burger TNT
            </a>
            <p>
            Jangan lupa mampir ke outlet kami bertempat di lapangan kenari ke arah barat depan Jagal Kerbau Kawan Baru
            </p>
            <div class="footer_social">
              <a href="">
                <i class="fa fa-facebook" aria-hidden="true"></i>
              </a>
               <!-- <a href="">
                <i class="fa fa-twitter" aria-hidden="true"></i>
              </a>
              <a href="">
                <i class="fa fa-linkedin" aria-hidden="true"></i>
              </a> -->
              <a href="">
                <i class="fa fa-instagram" aria-hidden="true"></i>
              </a>
              <a href="">
                <i class="fa fa-whatsapp" aria-hidden="true"></i>
              </a>
              <!-- <a href="">
                <i class="fa fa-facebook" aria-hidden="true"></i>
              </a> -->
            </div>
          </div>
        </div>
        <div class="col-md-4 footer-col">
          <h4>
            jam Buka
          </h4>
          <p>
            Setiap hari
          </p>
          <p>
            16.00 WIB - 21.30 WIB
          </p>
        </div>
      </div>
      <div class="footer-info">
        <p>
          &copy; <span id="displayYear"></span> All Rights Reserved By
          <a href="https://html.design/">Reza Wardana</a><br><br>

        </p>
      </div>
    </div>
  </footer>